/* freebsd9 is a superset of freebsd4 */
#include "freebsd9.h"
#define freebsd10 freebsd10
